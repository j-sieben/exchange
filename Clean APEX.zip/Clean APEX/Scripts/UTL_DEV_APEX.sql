
-- Beispiel-Skript zur Erstellung des Controler-Package Codes

select utl_dev_apex.get_form_methods(
         p_application_id => 201,
         p_page_id => 3,
         p_static_id => 'EDIT_EMP_FORM',
         p_check_method => 'employee.validate_employee',
         p_insert_method => 'employee.merge_employee',
         p_update_method => 'employee.merge_employee',
         p_delete_method => 'employee.delete_employee')
  from dual;
  
/*
-- UI_PACKAGE-Body
-- SPEC
  -- Methods to maintain page edit_emp
  function validate_edit_emp
    return boolean;

  procedure process_edit_emp;

-- BODY
-- Global Variables
  g_page_values utl_apex.page_value_t;
  g_edit_emp_row employees%rowtype;
  
-- COPY_ROW method
  
  /* Helper method to copy session state values from an APEX page 
   * %usage  Is called to copy the actual session state of an APEX page into a PL/SQL table
   /
  procedure copy_edit_emp
  as
  begin
    pit.enter_detailed('copy_edit_emp');
  
    g_page_values := utl_apex.get_page_values('EDIT_EMP_FORM');
    g_edit_emp_row.hire_date := to_date(utl_apex.get(g_page_values, 'hire_date'), 'DS');
    g_edit_emp_row.first_name := utl_apex.get(g_page_values, 'first_name');
    g_edit_emp_row.last_name := utl_apex.get(g_page_values, 'last_name');
    g_edit_emp_row.email := utl_apex.get(g_page_values, 'email');
    g_edit_emp_row.phone_number := utl_apex.get(g_page_values, 'phone_number');
    g_edit_emp_row.job_id := utl_apex.get(g_page_values, 'job_id');
    g_edit_emp_row.employee_id := to_number(utl_apex.get(g_page_values, 'employee_id'), 'fm9999999999990d99999999');
    g_edit_emp_row.salary := to_number(utl_apex.get(g_page_values, 'salary'), 'fm9999999999990d99999999');
    g_edit_emp_row.commission_pct := to_number(utl_apex.get(g_page_values, 'commission_pct'), 'FM990D0');
    g_edit_emp_row.manager_id := to_number(utl_apex.get(g_page_values, 'manager_id'), 'fm9999999999990d99999999');
    g_edit_emp_row.department_id := to_number(utl_apex.get(g_page_values, 'department_id'), 'fm9999999999990d99999999');
  
    pit.leave_detailed;
  end copy_edit_emp;
    
-- METHOD IMPLEMENTATIONS

  function validate_edit_emp
    return boolean
  as
  begin
    pit.enter_mandatory;
  
    copy_edit_emp;
    
    pit.start_message_collection;
    employee.validate_employee(g_edit_emp_row);
    pit.stop_message_collection;
  
    pit.leave_mandatory;
    return true;
  exception
    when msg.PIT_BULK_ERROR_ERR or msg.PIT_BULK_FATAL_ERR then
      utl_apex.handle_bulk_error(char_table(
        'ERROR_CODE', 'ASSIGNED_ITEM'));
      return true;
  end validate_edit_emp;
  
  
  procedure process_edit_emp
  as
  begin
    pit.enter_mandatory;
    
    copy_edit_emp;
    case when utl_apex.inserting or utl_apex.updating then
      employee.merge_employee(g_edit_emp_row);
    else
      employee.delete_employee(g_edit_emp_row);
    end case;
    
    pit.leave_mandatory;
  end process_edit_emp;
*/



-- Anpassung der Ausgabe ueber Modifikation der Templates aus UTL_TEXT_TEMPLATES:
select *  
  from utl_text_templates
 where uttm_type = 'APEX_FORM';


-- Abbildung einer Tabelle auf eine APEX-Collection
select utl_dev_apex.get_collection_view(
         p_source_table => 'EMPLOYEES',
         p_page_view => 'EMP_UI_EDIT_EMP')
  from dual;
  
/*
create or replace force view EMP_UI_EDIT_EMP as
select seq_id,
       n001 employee_id,
       C001 first_name,
       C002 last_name,
       C003 email,
       C004 phone_number,
       d001 hire_date,
       C005 job_id,
       n002 salary,
       n003 commission_pct,
       n004 manager_id,
       n005 department_id
  from apex_collections
 where collection_name = 'EMP_UI_EDIT_EMP'
*/


-- Erstelle Methoden auf Basis der Collection API (Beispiel aus ADC-Admin-Anwendung)
select utl_dev_apex.get_collection_methods(
         p_application_id => 117,
         p_page_id => 11,
         p_static_id => 'EDIT_CRA_FORM')
  from dual;
  
/*
create or replace package edit_cra_ui
  authid definer
as

  function validate_edit_cra
    return boolean;
    
  procedure process_edit_cra;

end edit_cra_ui;
/

create or replace package body edit_cra_ui
as

  
  g_page_values utl_apex.page_value_t;
  g_edit_cra_row adc_ui_edit_cra%rowtype;
  
  procedure copy_edit_cra
  as
  begin
    g_page_values := utl_apex.get_page_values;
    g_edit_cra_row.seq_id := to_number(utl_apex.get(g_page_values, 'seq_id'), 'fm9999999999990d99999999');
    g_edit_cra_row.cra_id := to_number(utl_apex.get(g_page_values, 'cra_id'), 'FM999999990');
    g_edit_cra_row.cra_cgr_id := to_number(utl_apex.get(g_page_values, 'cra_cgr_id'), 'FM999999990');
    g_edit_cra_row.cra_cru_id := to_number(utl_apex.get(g_page_values, 'cra_cru_id'), 'FM999999990');
    g_edit_cra_row.cra_cpi_id := utl_apex.get(g_page_values, 'cra_cpi_id');
    g_edit_cra_row.cra_cat_id := utl_apex.get(g_page_values, 'cra_cat_id');
    g_edit_cra_row.cra_param_1 := utl_apex.get(g_page_values, 'cra_param_1');
    g_edit_cra_row.cra_param_lov_1 := utl_apex.get(g_page_values, 'cra_param_lov_1');
    g_edit_cra_row.cra_param_area_1 := utl_apex.get(g_page_values, 'cra_param_area_1');
    g_edit_cra_row.cra_param_2 := utl_apex.get(g_page_values, 'cra_param_2');
    g_edit_cra_row.cra_param_lov_2 := utl_apex.get(g_page_values, 'cra_param_lov_2');
    g_edit_cra_row.cra_param_area_2 := utl_apex.get(g_page_values, 'cra_param_area_2');
    g_edit_cra_row.cra_param_3 := utl_apex.get(g_page_values, 'cra_param_3');
    g_edit_cra_row.cra_param_lov_3 := utl_apex.get(g_page_values, 'cra_param_lov_3');
    g_edit_cra_row.cra_param_area_3 := utl_apex.get(g_page_values, 'cra_param_area_3');
    g_edit_cra_row.cra_comment := utl_apex.get(g_page_values, 'cra_comment');
    g_edit_cra_row.cra_on_error := utl_apex.get(g_page_values, 'cra_on_error');
    g_edit_cra_row.cra_raise_recursive := utl_apex.get(g_page_values, 'cra_raise_recursive');
    g_edit_cra_row.cra_sort_seq := to_number(utl_apex.get(g_page_values, 'cra_sort_seq'), 'FM999999990');
    g_edit_cra_row.cra_active := utl_apex.get(g_page_values, 'cra_active');
    g_edit_cra_row.cra_has_error := utl_apex.get(g_page_values, 'cra_has_error');
  end copy_edit_cra;
  
  
  function validate_edit_cra
    return boolean
  as
  begin
    pit.enter_mandatory;

    -- copy_edit_cra;
    -- TODO: validation logic goes here. If it exists, uncomment COPY function

    pit.leave_mandatory;
    return true;
  end validate_edit_cra;
  
    
  procedure process_edit_cra
  as
    c_collection_name constant varchar2(30 byte) := 'adc_ui_edit_cra';
  begin
    pit.enter_mandatory;

    copy_edit_cra;  
    case
    when utl_apex.INSERTING then
      apex_collection.add_member(
        p_collection_name => c_collection_name,
        p_n001 => g_edit_cra_row.seq_id,
        p_n002 => g_edit_cra_row.cra_id,
        p_n003 => g_edit_cra_row.cra_cgr_id,
        p_n004 => g_edit_cra_row.cra_cru_id,
        p_c001 => g_edit_cra_row.cra_cpi_id,
        p_c002 => g_edit_cra_row.cra_cat_id,
        p_c003 => g_edit_cra_row.cra_param_1,
        p_c004 => g_edit_cra_row.cra_param_lov_1,
        p_c005 => g_edit_cra_row.cra_param_area_1,
        p_c006 => g_edit_cra_row.cra_param_2,
        p_c007 => g_edit_cra_row.cra_param_lov_2,
        p_c008 => g_edit_cra_row.cra_param_area_2,
        p_c009 => g_edit_cra_row.cra_param_3,
        p_c010 => g_edit_cra_row.cra_param_lov_3,
        p_c011 => g_edit_cra_row.cra_param_area_3,
        p_c012 => g_edit_cra_row.cra_comment,
        p_c013 => g_edit_cra_row.cra_on_error,
        p_c014 => g_edit_cra_row.cra_raise_recursive,
        p_n005 => g_edit_cra_row.cra_sort_seq,
        p_c015 => g_edit_cra_row.cra_active,
        p_c016 => g_edit_cra_row.cra_has_error,
        p_generate_md5 => c_no);
    when utl_apex.UPDATING then
      apex_collection.update_member(
        p_seq => g_edit_cra_row.seq_id,
        p_collection_name => c_collection_name,
        p_n001 => g_edit_cra_row.seq_id,
        p_n002 => g_edit_cra_row.cra_id,
        p_n003 => g_edit_cra_row.cra_cgr_id,
        p_n004 => g_edit_cra_row.cra_cru_id,
        p_c001 => g_edit_cra_row.cra_cpi_id,
        p_c002 => g_edit_cra_row.cra_cat_id,
        p_c003 => g_edit_cra_row.cra_param_1,
        p_c004 => g_edit_cra_row.cra_param_lov_1,
        p_c005 => g_edit_cra_row.cra_param_area_1,
        p_c006 => g_edit_cra_row.cra_param_2,
        p_c007 => g_edit_cra_row.cra_param_lov_2,
        p_c008 => g_edit_cra_row.cra_param_area_2,
        p_c009 => g_edit_cra_row.cra_param_3,
        p_c010 => g_edit_cra_row.cra_param_lov_3,
        p_c011 => g_edit_cra_row.cra_param_area_3,
        p_c012 => g_edit_cra_row.cra_comment,
        p_c013 => g_edit_cra_row.cra_on_error,
        p_c014 => g_edit_cra_row.cra_raise_recursive,
        p_n005 => g_edit_cra_row.cra_sort_seq,
        p_c015 => g_edit_cra_row.cra_active,
        p_c016 => g_edit_cra_row.cra_has_error);
    when utl_apex.DELETING then
      apex_collection.delete_member(
        p_seq => g_edit_cra_row.seq_id,
        p_collection_name => c_collection_name);
    else
      null;
    end case;

    pit.leave_mandatory;
  end process_edit_cra;

end edit_cra_ui;
/

*/