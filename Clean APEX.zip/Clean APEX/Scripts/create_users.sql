grant create view, create materialized view, create synonym to resource;


create user utils identified by utils default tablespace users;
grant connect, resource to utils;


create user apex_data identified by apex_data default tablespace users;
grant connect, resource to apex_data;


create user apex_app identified by apex_app default tablespace users;
grant connect, resource to apex_app;
