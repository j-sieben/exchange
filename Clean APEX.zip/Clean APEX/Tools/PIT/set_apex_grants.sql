
@tools/check_has_system_privilege.sql "create session"
