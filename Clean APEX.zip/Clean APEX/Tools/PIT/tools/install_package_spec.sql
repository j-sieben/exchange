prompt &s1.Create package specification &1.
@&pkg_dir.&1..pks
show errors