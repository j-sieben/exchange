prompt &s1.Create type body &1.
@&type_dir.&1..tpb
show errors