prompt &s1.Script &1.
@&script_dir.&1..sql