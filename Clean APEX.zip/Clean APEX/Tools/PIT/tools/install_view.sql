prompt &s1.Create view &1.
@&view_dir.&1..vw