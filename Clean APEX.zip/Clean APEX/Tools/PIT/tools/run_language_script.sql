prompt &s1.Script &1.
@&msg_dir.&1..sql