prompt &s1.Create type specification &1.
@&type_dir.&1..tps
show errors