prompt &s1.Create package body &1.
@&pkg_dir.&1..pkb
show errors