begin
  param_admin.edit_parameter_type('STRING', 'Einfache Texte');
  param_admin.edit_parameter_type('HTML', 'HTML-Instanzen');
  param_admin.edit_parameter_type('SQL', 'SQL-Anweisungen');
  
  commit;
end;
/
