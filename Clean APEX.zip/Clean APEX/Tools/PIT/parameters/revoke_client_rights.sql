
@tools/revoke_access.sql execute param
@tools/revoke_access.sql execute param_admin

@tools/revoke_access.sql "select, references" parameter_group
@tools/revoke_access.sql "select, references" parameter_realm
@tools/revoke_access.sql "select, references" parameter_tab
@tools/revoke_access.sql "select, references" parameter_type
@tools/revoke_access.sql select parameter_core_vw
@tools/revoke_access.sql select parameter_realm_vw
