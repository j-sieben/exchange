prompt &s1.Grant execute on UTL_SMTP
@tools/check_has_object_privilege execute utl_smtp

prompt &s1.Grant execute on UTL_TCP
@tools/check_has_object_privilege execute utl_tcp

prompt &s1.Grant execute on UTL_ENCODE
@tools/check_has_object_privilege execute utl_encode

prompt &s1.Grant execute on DBMS_CRYPTO
@tools/check_has_object_privilege execute dbms_crypto

