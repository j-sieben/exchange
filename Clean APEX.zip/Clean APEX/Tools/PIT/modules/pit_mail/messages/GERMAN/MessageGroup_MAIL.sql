begin

  pit_admin.merge_message_group(
    p_pmg_name => 'MAIL',
    p_pmg_description => 'Messages for MAIL package');

  pit_admin.merge_message(
    p_pms_name => 'MAIL_PKG_NOT_WORKING',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Fehler beim Versuch, das MAIL-Package zu initialisieren.^',
    p_pms_description => q'^Initialisierungsfehler deuten auf falsche Parameterwerte für das PIT_MAIL-Ausgabemodul hin. Bitte prüfen Sie die Parameter.^',
    p_pms_pse_id => 30,
    p_pms_pml_name => 'GERMAN',
    p_error_number => -20000
  );
  
  pit_admin.merge_message(
    p_pms_name => 'MAIL_ERROR',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => 'Fehler beim Versenden einer Email: #1#, #2#',
    p_pms_description => q'^Generische Fehlernachricht für Fehler beim Versenden einer Mail.^',
    p_pms_pse_id => 30,
    p_pms_pml_name => 'GERMAN');
  
  pit_admin.merge_message(
    p_pms_name => 'INVALID_MIME_TYPE',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Ungültiger Mime-Typ:#1#^',
    p_pms_description => q'^Der Typ der zu übertragenden Datei ist ein Format, das von MAIL nicht unterstützt wird.^',
    p_pms_pse_id => 30,
    p_pms_pml_name => 'GERMAN',
    p_error_number => -20000
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_DELIVERY_FAILED',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Fehler beim Versenden der E-Mail^',
    p_pms_description => q'^Der Versand konnte aus einem unbekannten Grund nicht ausgeführt werden. Bitte wenden Sie sich an den Support.^',
    p_pms_pse_id => 30,
    p_pms_pml_name => 'GERMAN',
    p_error_number => -20000
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_LOG',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^#1#^',
    p_pms_description => q'^^',
    p_pms_pse_id => 60,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_LOGIN_METHODS',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Unterstützte Authentifizierungsverfahren: '#1#'^',
    p_pms_description => q'^^',
    p_pms_pse_id => 60,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SENDER',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Absender: '#1#'^',
    p_pms_description => q'^^',
    p_pms_pse_id => 60,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_RECIPIENTS',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Empfänger: '#1#'^',
    p_pms_description => q'^^',
    p_pms_pse_id => 60,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SENT',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Mail erfolgreich versendet.^',
    p_pms_description => q'^^',
    p_pms_pse_id => 60,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SERVER_ACCESS_DENIED',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Die Datenbank hat den Zugriff auf den Mail-Server verweigert.^',
    p_pms_description => q'^Ab Version 11g benötigt Oracle eine Freigabe für den Zugriff auf eine Netzressource. Stellen Sie sicher, dass die Datenbank auf diese Ressource zugreifen darf.^',
    p_pms_pse_id => 30,
    p_pms_pml_name => 'GERMAN',
    p_error_number => -20000
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SERVER_ACCESS_GRANTED',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Die Datenbank hat den Zugriff auf den Mail-Server gestattet.^',
    p_pms_description => q'^^',
    p_pms_pse_id => 70,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SERVER_ACCESSIBLE',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Der Mail-Server ist erreichbar.^',
    p_pms_description => q'^^',
    p_pms_pse_id => 70,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SERVER_CONNECTED',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Verbindung zum Mailserver hergestellt.^',
    p_pms_description => q'^^',
    p_pms_pse_id => 60,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SERVER_DISCONNECTED',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Verbindung zum Mailserver beendet.^',
    p_pms_description => q'^^',
    p_pms_pse_id => 60,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_SERVER_UNAVAILABLE',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Der Mail-Server ist nicht erreichbar.^',
    p_pms_description => q'^Die Verbindung zum Mailserver ist zwar erlaubt, doch technisch nicht möglich. Grund könnte sein, dass der Mailserver auf einem anderen Port eingerichtet oder abgeschaltet ist.^',
    p_pms_pse_id => 30,
    p_pms_pml_name => 'GERMAN',
    p_error_number => -20000
  );

  pit_admin.merge_message(
    p_pms_name => 'MAIL_TEST',
    p_pms_pmg_name => 'MAIL',
    p_pms_text => q'^Das ist eine Testmail zum Nachweis, dass die Verbindung funktioniert.^',
    p_pms_description => q'^^',
    p_pms_pse_id => 70,
    p_pms_pml_name => 'GERMAN',
    p_error_number => null
  );


  commit;
  pit_admin.create_message_package;
  
end;
/