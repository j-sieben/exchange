
@tools/revoke_access.sql select PIT_TABLE_LOG;
@tools/revoke_access.sql select PIT_TABLE_CALL_STACK;
@tools/revoke_access.sql select PIT_TABLE_CALL_PARAMS;