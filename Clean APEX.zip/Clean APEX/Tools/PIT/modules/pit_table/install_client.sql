
@tools/grant_access.sql select PIT_TABLE_LOG;
@tools/grant_access.sql select PIT_TABLE_CALL_STACK;
@tools/grant_access.sql select PIT_TABLE_PARAMS;