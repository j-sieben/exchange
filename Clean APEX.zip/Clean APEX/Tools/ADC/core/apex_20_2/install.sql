
prompt &s1.Create view ADC_BL_PAGE_TARGETS
@&apex_version.views/adc_bl_page_targets.vw
