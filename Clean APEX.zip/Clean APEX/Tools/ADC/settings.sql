-- Central settings. Change Flagtype and installation options here.

define FLAG_TYPE="char(1 byte)";
define C_TRUE="'Y'";
define C_FALSE="'N'";

--define FLAG_TYPE="number(1, 0)";
--define C_TRUE=1;
--define C_FALSE=0;

define MIN_UT_VERSION="v3.1"
define WITH_UT=false
