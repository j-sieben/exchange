To install UTL_TEXT, 

- move to this folder from within a command line
- set NLS_LANG to GERMAN_GERMANY.AL32UTF8 to avoid problems with umlaute and Unicode characters
- call utl_text_install.sql with the name of the owner of the tool wihtin your database and the default language

